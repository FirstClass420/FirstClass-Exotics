FIRSTCLASS EXOTICS — FREE WEBSITE

FILES
- index.html: the complete responsive website. No build tools or paid software required.

PREVIEW
1. Download and unzip the package.
2. Open index.html in Chrome, Edge, Firefox, or Safari.

PUBLISH FOR FREE (GitHub Pages)
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository named firstclass-exotics (or another available name).
3. Upload index.html to the repository root. You can also upload this README.
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose the main branch and /(root), then Save.
7. Wait for GitHub Pages to publish. Your URL will look like:
   https://YOUR-USERNAME.github.io/firstclass-exotics/

IMPORTANT
- Hosting providers have acceptable-use rules and may restrict cannabis-related commerce or promotion. Check current GitHub Pages terms and all applicable local laws before publishing.
- This template is informational and does not process payments or orders.
- It is not a substitute for a legally required age-verification system or business licensing.
- Social profile links are set to instagram.com/unixwyd and tiktok.com/@unixwyd. Edit index.html if needed.
- Product categories are placeholders. Only add product listings or sales information that you are legally authorized to advertise.
